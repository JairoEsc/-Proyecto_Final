$(document).ready(function(){
    $.ajax({
        url:'php/Session.php',
        type: 'POST',
        success: function (e){
            if(e==1){
                location.href="perfil.html";
            }
        }
    })
    
    $('#iniciar').submit(function(e){
        var datos = new FormData($('#iniciar')[0])
        var perfil= 0;
        $.ajax({
            url:'php/Ingresar.php',
            type: 'POST',
            data: datos,
            contentType: false,
            processData: false,
            success: function (e){
                if(e==1){
                    location.href="perfil.html";
                }else{
                    Swal.fire({
                        icon: 'warning',
                        title: 'Usuario o contraseña incorrecta',
                    })
                }
            }
        }) 
        e.preventDefault();
    })
    $('#formModal').submit(function(e){
        var datos = new FormData($('#formModal')[0])
        $.ajax({
            url:'php/NuevoUser.php',
            type: 'POST',
            data: datos,
            contentType: false,
            processData: false,
            success: function (e){

                
            }
        }) 
        e.preventDefault();
    })

 });

