$(document).ready(function(){
    galeria();
    function galeria(){
        $.ajax({
            url: 'php/LlenarGaleria.php',
            type:'GET',
            success: function(respuesta){
                let menu = $.parseJSON(respuesta);
                let templase = '';
                var i=1;
                menu.forEach(element => {
                    templase += `
                    <div class="col-lg-4 col-md-6 col-sm-12" >
                        
                        <a href="img/${element.img}" data-footer="${element.com}" data-toggle="lightbox" data-gallery="example-gallery">
                            <img src="img/${element.img}" class="img-fluid">
                        </a>
                        
                    </div>
                    
                    `
                });
                $('#galeria').html(templase);
            }
        })
    }

    $('#formModal').submit(function(e){
        var datos = new FormData($('#formModal')[0])
        $.ajax({
            url:'php/IngresarImg.php',
            type: 'POST',
            data: datos,
            contentType: false,
            processData: false,
            success: function (e){
                galeria();
                Swal.fire({
                    icon: 'success',
                    title: 'Imagen Gurdada',
                })
                
            }
        }) 
        e.preventDefault();
    })

    $.ajax({
        url:'php/Session.php',
        type: 'POST',
        success: function (e){
            if(e==0){
                location.href="loagin.html";
            }
        }
    })
    $.ajax({
        url: 'php/CargarDatos.php',
        type:'GET',
        success: function(respuesta){
            let menu = $.parseJSON(respuesta);
            let templase = '';
            var i=1;
            menu.forEach(element => {
                templase += `
                <div class="row datos-perfil">
                    <div class="col-4 color ">
                        <div class="foto-perfil">
                        <img src="img/${element.Perfil}" alt="" width="500" height="600">
                        </div>
                </div>
                    <div class="col-8 nombre">
                    <div class="datos-user">
                        <div class="row">   
                            <div class="col-5">
                                <h2>${element.Usuario}</h2>
                            </div>
                            
                        </div>
                        
                        <div class="row">
                            <div class="col">
                                <label for="">
                                    <h5>${element.Nombre} ${element.Apellido}</h5>
                                </label>
                            </div>
                            
                           
                        </div>
                    
                        <div class="row">
                            <div class="col-4">
                                <button class="btn btn-primary">Editar perfil</button>
                            </div>
                            <div class="col-5">
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#ingresar">Ingresar Imagen</button>
                            </div>
                        </div>
                        
                    </div>
                    </div>
                </div>
                <hr>
                `
            });
            $('#datos').html(templase);
        }
    })
    
    
 });

 function CerrarSession(){
    console.log("aqui");
    $.ajax({
        url:'php/CerrarSession.php',
        type: 'POST',
        success: function (e){
            if(e==1){
                location.href="loagin.html";
            }
        }
    }) 
 }

