<?php
    $server = "localhost";
    $user = "DiPablo";
    $pass = "1234";
    $db = "galeria";

    $con = mysqli_connect($server,$user,$pass,$db);
    
?>
