<?php
    include ("conexion.php");
	session_start();

	$id= $_SESSION['id'];

    $query = "SELECT id, comentario,
	(SELECT imagen FROM imagenes WHERE id=imagenes_id) 
	FROM usuario_imagen Where usuario_id=$id ORDER BY id DESC";
	$result = mysqli_query($con,$query); 

    $json = array();  
    
	while($row = mysqli_fetch_row($result)){ 
		$json[] = array(
			'id' => $row[0],
			'com' => $row[1],
			'img' => $row[2]
		);
	}

	$jsonstring = json_encode($json);
    echo $jsonstring;
    mysqli_close($con);
?>