<?php
    include ("conexion.php");
    session_start();
    session_unset();
    session_destroy();

    echo "1";
    
    mysqli_close($con);
?>
