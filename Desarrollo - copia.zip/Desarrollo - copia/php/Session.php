<?php
    include ("conexion.php");
    session_start();
    if(isset($_SESSION['usuario'])){
        echo "1";
    }else{
        echo "0";
    }
    
    
    mysqli_close($con); 
?>