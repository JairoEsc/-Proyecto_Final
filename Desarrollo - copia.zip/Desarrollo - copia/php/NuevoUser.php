<?php
    include ("conexion.php");
    if(isset($_POST['usuario']) && isset($_POST['contrasenia']) && isset($_POST['nombre']) && isset($_POST['correo'])){
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $correo = $_POST['correo'];
        $usuario = $_POST['usuario'];                                 
        $contrasenia = $_POST['contrasenia'];

        $contrasenia = hash('sha512', $contrasenia);

        $query2 = mysqli_query($con, "INSERT INTO USUARIO (nombre, apellido, correo, nom_usuario, contrasenia,perfil) VALUES ('$nombre','$apellido','$correo', '$usuario', '$contrasenia','perfil.png')");
        if(mysqli_query($con,$query2)){       
            //   header("Refresh: 4; url = inicio.html");
        }  
    }
    
    mysqli_close($con);
    
?>