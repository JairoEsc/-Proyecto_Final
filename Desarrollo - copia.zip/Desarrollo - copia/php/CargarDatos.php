<?php

    include ("conexion.php");
    session_start();

    if(isset($_SESSION['usuario'])){
        $json = array(); //Variable json  
        $json[] = array(
            'Nombre'=>  $_SESSION['nombre'],
            'Apellido'=> $_SESSION['apellido'],
            'Usuario'=> $_SESSION['usuario'],
            'Perfil'=> $_SESSION['perfil']
        );
        
        $jsonstring = json_encode($json);
        echo $jsonstring;
        
    }
   

?>