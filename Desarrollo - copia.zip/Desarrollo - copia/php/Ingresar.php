<?php
    include ("conexion.php");
    session_start();
    if(isset($_SESSION['usuario'])){
        echo 1;
    }else
    
    if(isset($_POST['usuario']) && isset($_POST['contrasenia'])){
        $usuario = mysqli_real_escape_string($con, $_POST['usuario']);
        $usuario = strip_tags($_POST['usuario']);
        $usuario = trim($_POST['usuario']);
        

        $contrasenia = mysqli_real_escape_string($con,$_POST['contrasenia']);
        $contrasenia = strip_tags($_POST['contrasenia']);
        $contrasenia = trim($_POST['contrasenia']);
        $contrasenia = hash('sha512', $contrasenia);

        
        $query = mysqli_query($con, "SELECT *FROM USUARIO WHERE nom_usuario ='$usuario' AND contrasenia ='$contrasenia'");
        $contar = mysqli_num_rows($query);

        if($contar==true){
            while($row=mysqli_fetch_row($query)) {
                $_SESSION['id'] = $row[0];
                $_SESSION['nombre'] =  $row[1];
                $_SESSION['apellido'] =  $row[2];
                $_SESSION['usuario'] =  $row[4];
                $_SESSION['perfil'] =  $row[6];
                echo 1;
            }
        }


    }
    
    mysqli_close($con); 
?>