<?php
    include ("conexion.php");
    session_start();
    $id= $_SESSION['id'];
    $com= $_POST["comentario"];
    $img= $_FILES["fileImg"]["name"];

    
    if(isset($img)&& $img!=""){
        $query1="INSERT INTO imagenes (imagen) value('$img')";
        $result1= mysqli_query($con,$query1);

        $query2="SELECT id FROM imagenes ORDER BY id DESC LIMIT 1";
        $result2= mysqli_query($con,$query2);

        while($row=mysqli_fetch_row($result2)){
            $id_img=$row[0];
            $query3="INSERT INTO usuario_imagen (fecha,comentario,usuario_id,imagenes_id) value(CURDATE(),'$com',$id,$id_img)";
            $result3 = mysqli_query($con,$query3);
        }

        
        if($result3==true && $result1==true){
            $tipo =$_FILES['fileImg']["type"];
            $temp =$_FILES['fileImg']["tmp_name"];
            move_uploaded_file($temp,'../img/'.$img);
            echo "Dato ingresado";
        }
    }
    mysqli_close($con);
?>
